import { components as SelectPrimitives } from "react-select"

export default SelectPrimitives
