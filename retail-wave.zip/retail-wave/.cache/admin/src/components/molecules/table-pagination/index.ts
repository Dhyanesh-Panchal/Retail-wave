export { TablePagination as default } from "./table-pagination"
